#!/bin/bash
cd "$(dirname "$0")"
echo "Instalando ReaderPro..."
xattr -cr ReaderPro.app
cp -R ReaderPro.app /Applications/
open /Applications/ReaderPro.app
echo "Instalado en /Applications"
